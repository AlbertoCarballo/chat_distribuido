import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { io } from "socket.io-client";

function Login() {
    const [nombreUsuario, setNombreUsuario] = useState("");
    const [contraseña, setContraseña] = useState("");
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const socketRef = useRef(null);

    const ipCliente = "192.168.1.162";

    useEffect(() => {
        // Crear la conexión socket al montar el componente
        socketRef.current = io("http://192.168.1.162:3001");

        // Limpiar el socket al desmontar
        return () => {
            if (socketRef.current) {
                socketRef.current.disconnect();
            }
        };
    }, []);

    const handleLogin = (e) => {
        e.preventDefault();
        setError(null);

        if (!socketRef.current) {
            setError("No hay conexión con el servidor.");
            return;
        }

        socketRef.current.emit(
            "login",
            { nombreUsuario, contraseña, ip: ipCliente },
            (response) => {
                if (response.success) {
                    localStorage.setItem("usuario", nombreUsuario);
                    // Desconectamos el socket porque ya no lo necesitamos aquí
                    socketRef.current.disconnect();
                    navigate("/chat");
                } else {
                    setError(response.mensaje);
                }
            }
        );
    };

    const irARegistro = () => {
        navigate("/registro");
    };

    return (
        <form onSubmit={handleLogin} style={{ maxWidth: 300, margin: "auto", marginTop: 50 }}>
            <h2>Login</h2>
            <input
                type="text"
                placeholder="Nombre de usuario"
                value={nombreUsuario}
                onChange={(e) => setNombreUsuario(e.target.value)}
                required
                style={{ width: "100%", marginBottom: 10, padding: 8 }}
            />
            <input
                type="password"
                placeholder="Contraseña"
                value={contraseña}
                onChange={(e) => setContraseña(e.target.value)}
                required
                style={{ width: "100%", marginBottom: 10, padding: 8 }}
            />
            {error && <p style={{ color: "red" }}>{error}</p>}
            <button type="submit" style={{ width: "100%", padding: 10, marginBottom: 10 }}>
                Entrar
            </button>
            <button
                type="button"
                onClick={irARegistro}
                style={{ width: "100%", padding: 10, backgroundColor: "#ccc" }}
            >
                Registrar
            </button>
        </form>
    );
}

export default Login;
